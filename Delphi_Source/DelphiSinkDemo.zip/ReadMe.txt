Delphi 4 Eventsink Demo

1) Build EventServer.dpr (in Server\) and then register EventServer.exe

2) Install the sink components in EventServerEvents.pas (in Client\) file into
   your Delphi environment (Component | Install Component)

3) Open, build, then run EventClient.dpr

4) Click "Create EventServer.EventSource" and you'll see message boxes
   indicating the callbacks triggered from the EventServer.EventSource object

